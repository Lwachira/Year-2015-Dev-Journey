﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using System.IO;
namespace s213200619_Baywest
{
    public partial class frmRegister : MetroForm
    {
        public frmRegister()
        {
            InitializeComponent();
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            int loginID = int.Parse(txtLoginID.Text.Trim());
            try
            {
                StreamWriter myWriter = new StreamWriter(@"Files\registration.txt", true);
                myWriter.WriteLine(loginID.ToString() + "#" + txtUsername.Text + "#" + txtRank.Text + "#");
                myWriter.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
