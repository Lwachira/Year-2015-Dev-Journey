﻿Module Module2

    Sub Main()
        Console.Write("Hi")

        Console.ReadLine()
    End Sub

End Module